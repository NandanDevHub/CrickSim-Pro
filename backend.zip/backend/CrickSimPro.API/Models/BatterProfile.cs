namespace CrickSimPro.API.Models;

public class BatterProfile
{
    public string Name { get; set; }
    public string Type { get; set; }
}
